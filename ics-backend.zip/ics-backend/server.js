import express from 'express';
import fetch from 'node-fetch';
import ICAL from 'ical.js';

const app = express();
const PORT = process.env.PORT || 3000;

const salas = {
  empatia: 'https://outlook.office365.com/owa/calendar/8f510ab44e524bf880df0271f2d95b9b@tecmx.onmicrosoft.com/74ba31b00a7a4b379af98254324bf00e6280432118622839938/calendar.ics',
  transformar: 'https://outlook.office365.com/owa/calendar/c3b8888cfa2d4892b2299cde3ab930c@itesm.mx/15c116d535094c3d8c1327d574116dbb4571580564513920580/calendar.ics',
  empatiae: 'https://outlook.office365.com/owa/calendar/04467ece315449ca84464493baa4dd0a@itesm.mx/6057bac905c6409e81bad5f20a4c501812053752749908351378/calendar.ics'
};

app.get('/ics/:sala', async (req, res) => {
  const icsURL = salas[req.params.sala.toLowerCase()];
  if (!icsURL) return res.status(404).json({ error: 'Sala no encontrada' });

  try {
    const response = await fetch(icsURL, {
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'text/calendar'
      }
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status} - ${response.statusText}`);
    }

    const icsText = await response.text();
    const jcalData = ICAL.parse(icsText);
    const comp = new ICAL.Component(jcalData);
    const vevents = comp.getAllSubcomponents('vevent');

    const events = vevents.map(evt => {
      const e = new ICAL.Event(evt);
      return {
        title: e.summary,
        start: e.startDate.toString(),
        end: e.endDate.toString()
      };
    });

    res.json(events);
  } catch (err) {
    console.error('❌ Error al procesar:', err.message);
    res.status(500).json({ error: 'Error al obtener o procesar el ICS' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
